/* =========================================================
   iCONI Agency — main.js
   Vanilla JS. No libraries.
   ========================================================= */
(function () {
  'use strict';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- sticky header ---------- */
  var header = document.getElementById('header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('is-stuck', window.pageYOffset > 12);
    }, { passive: true });
  }

  /* ---------- mobile menu ---------- */
  var burger = document.getElementById('burger');
  var nav = document.getElementById('nav');
  if (burger && nav) {
    burger.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.style.overflow = open ? 'hidden' : '';
    });

    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        if (window.innerWidth <= 720 && !a.parentElement.classList.contains('has-sub')) {
          nav.classList.remove('is-open');
          burger.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        }
      });
    });

    nav.querySelectorAll('.has-sub > a').forEach(function (a) {
      a.addEventListener('click', function (e) {
        if (window.innerWidth <= 720) {
          e.preventDefault();
          a.parentElement.classList.toggle('is-open');
        }
      });
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        burger.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });
  }

  /* ---------- scroll reveal ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if (reduce || !('IntersectionObserver' in window)) {
    reveals.forEach(function (el) { el.classList.add('in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
        reveals.forEach(function (el) { io.observe(el); });

    /* Safety net: if the page loaded with a #hash, force-reveal anything above the fold */
    if (window.location.hash) {
      var target = document.querySelector(window.location.hash);
      if (target) {
        var rect = target.getBoundingClientRect();
        if (rect.top < window.innerHeight) {
          target.classList.add('in');
          var parent = target.closest('.reveal');
          if (parent) parent.classList.add('in');
          var allInPath = target.parentElement;
          while (allInPath) {
            if (allInPath.classList && allInPath.classList.contains('reveal')) {
              allInPath.classList.add('in');
            }
            allInPath = allInPath.parentElement;
          }
        }
      }
    }
  }

  /* ---------- counters ---------- */
  var counters = document.querySelectorAll('.counter[data-count]');
  function runCounter(el) {
    var target = parseInt(el.getAttribute('data-count'), 10) || 0;
    if (reduce) { el.textContent = target; return; }
    var dur = 1400, start = performance.now();
    (function tick(now) {
      var p = Math.min((now - start) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.floor(eased * target);
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = target;
    })(start);
  }
  if ('IntersectionObserver' in window && counters.length) {
    var co = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { runCounter(entry.target); co.unobserve(entry.target); }
      });
    }, { threshold: 0.5 });
    counters.forEach(function (el) { co.observe(el); });
  } else {
    counters.forEach(runCounter);
  }

  /* ---------- skill bars ---------- */
  var fills = document.querySelectorAll('.skill__fill[data-percent]');
  if ('IntersectionObserver' in window && fills.length) {
    var bo = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.width = entry.target.getAttribute('data-percent') + '%';
          bo.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    fills.forEach(function (el) { bo.observe(el); });
  } else {
    fills.forEach(function (el) { el.style.width = el.getAttribute('data-percent') + '%'; });
  }

  /* ---------- pricing tabs ---------- */
  var tabs = document.querySelectorAll('.pricing__tab');
  var panels = {
    starter: document.getElementById('panel-starter'),
    business: document.getElementById('panel-business'),
    advanced: document.getElementById('panel-advanced')
  };
  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var key = tab.getAttribute('data-tab');
      tabs.forEach(function (t) { t.classList.remove('is-active'); });
      tab.classList.add('is-active');
      Object.keys(panels).forEach(function (k) {
        if (panels[k]) panels[k].hidden = (k !== key);
      });
    });
  });

  /* ---------- team slider nav ---------- */
  var track = document.getElementById('teamTrack');
  if (track) {
    var step = function () {
      var first = track.querySelector('.team__item');
      return first ? first.getBoundingClientRect().width + 24 : 320;
    };
    document.querySelectorAll('.team__nav [data-slide]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var dir = btn.getAttribute('data-slide') === 'next' ? 1 : -1;
        track.scrollBy({ left: dir * step(), behavior: reduce ? 'auto' : 'smooth' });
      });
    });
  }

  /* ---------- scroll to top ---------- */
  var top = document.getElementById('scrollTop');
  if (top) {
    window.addEventListener('scroll', function () {
      top.classList.toggle('show', window.pageYOffset > 500);
    }, { passive: true });
    top.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
    });
  }

  /* ---------- current year ---------- */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
  /* ---------- circular dials (about page) ---------- */
  var dials = document.querySelectorAll('.abt-dial__fill[data-percent]');
  if ('IntersectionObserver' in window && dials.length) {
    var DIAL_R = 42;
    var DIAL_C = 2 * Math.PI * DIAL_R;
    dials.forEach(function (el) {
      el.style.strokeDasharray = DIAL_C;
      el.style.strokeDashoffset = DIAL_C;
    });
    var dobs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          var el = entry.target;
          var p = parseFloat(el.getAttribute('data-percent')) || 0;
          el.style.transition = 'stroke-dashoffset 1.6s cubic-bezier(.22,.61,.36,1)';
          el.style.strokeDashoffset = (DIAL_C - (p / 100) * DIAL_C).toString();
          dobs.unobserve(el);
        }
      });
    }, { threshold: 0.4 });
    dials.forEach(function (el) { dobs.observe(el); });
  }
    /* ---------- work-start filter tabs ---------- */
    var workTabs = document.querySelectorAll('#workTabs .work-start__tab');
  var workItems = document.querySelectorAll('#workGallery .work-start__item');
  if (workTabs.length && workItems.length) {
    workTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');

        /* Update active state */
        workTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');

        /* Filter items */
        workItems.forEach(function (item) {
          var cat = item.getAttribute('data-cat');
          var show = (cat === filter);
          item.classList.toggle('is-hidden', !show);
        });
      });
    });
  }
    /* ---------- portfolio filter tabs ---------- */
  var portTabs = document.querySelectorAll('#portfolioTabs .work-start__tab');
  var portItems = document.querySelectorAll('#portfolioGrid .work-start__item');
  if (portTabs.length && portItems.length) {
    portTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');
        portTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');
        portItems.forEach(function (item) {
          var cat = item.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          item.classList.toggle('is-hidden', !show);
        });
      });
    });
  }
    /* ---------- portfolio filter (Zebsite-style) ---------- */
  var portTabs = document.querySelectorAll('#portfolioTabs .port-filters__btn');
  var portCards = document.querySelectorAll('#portfolioGrid .pcard');
  if (portTabs.length && portCards.length) {
    portTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');
        portTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');
        portCards.forEach(function (card) {
          var cat = card.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          card.classList.toggle('is-hidden', !show);
        });
      });
    });
  }
    /* ---------- FAQ category filter ---------- */
  var faqTabs = document.querySelectorAll('#faqTabs .faq-tab');
  var faqCards = document.querySelectorAll('#faqList .faq-card');
  var faqTitles = document.querySelectorAll('#faqList .faq-group-title');
  if (faqTabs.length && faqCards.length) {
    faqTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');
        faqTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');

        faqCards.forEach(function (card) {
          var cat = card.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          card.classList.toggle('is-hidden', !show);
        });

        faqTitles.forEach(function (title) {
          var cat = title.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          title.style.display = show ? '' : 'none';
        });
      });
    });
  }
    /* ---------- auto-select position from URL ---------- */
  var posSelect = document.getElementById('aj-position');
  if (posSelect) {
    var params = new URLSearchParams(window.location.search);
    var position = params.get('position');
    if (position) {
      Array.from(posSelect.options).forEach(function (opt) {
        if (opt.text === position || opt.value === position) {
          posSelect.value = opt.value || opt.text;
        }
      });
    }
  }

  /* ---------- file name display ---------- */
  var fileInput = document.getElementById('aj-resume');
  var fileName = document.getElementById('fileName');
  if (fileInput && fileName) {
    fileInput.addEventListener('change', function () {
      if (fileInput.files.length > 0) {
        var file = fileInput.files[0];
        var sizeMB = (file.size / 1024 / 1024).toFixed(2);
        fileName.textContent = '✓ ' + file.name + ' (' + sizeMB + ' MB)';
      } else {
        fileName.textContent = '';
      }
    });
  }
    /* ---------- blog category filter ---------- */
  var blogTabs = document.querySelectorAll('#blogTabs .blog-tab');
  var blogCards = document.querySelectorAll('#blogGrid .blog-card');
  if (blogTabs.length && blogCards.length) {
    blogTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');
        blogTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');
        blogCards.forEach(function (card) {
          var cat = card.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          card.classList.toggle('is-hidden', !show);
        });
      });
    });
  }
    /* ---------- news / blog filter tabs ---------- */
  var newsTabs = document.querySelectorAll('#newsTabs .news-tab');
  var newsCards = document.querySelectorAll('#newsGrid .news-card');
  if (newsTabs.length && newsCards.length) {
    newsTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var filter = tab.getAttribute('data-filter');
        newsTabs.forEach(function (t) { t.classList.remove('is-active'); });
        tab.classList.add('is-active');
        newsCards.forEach(function (card) {
          var cat = card.getAttribute('data-cat');
          var show = (filter === 'all') || (cat === filter);
          card.classList.toggle('is-hidden', !show);
        });
      });
    });
  }
})();